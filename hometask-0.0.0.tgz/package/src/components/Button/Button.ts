export type ButtonProps={
  variant?:'primary' | 'secondary' | 'outline'|'danger';
  size?:'sm' | 'md' | 'lg';
  onClick?:()=>void;
  children?:React.ReactNode;
}